import time
import math
class mat:
    def circle():
        print("LOADING....")
        time.sleep(1)
        r = int(input("What is the Radius of the circle : "))
        pie = math.pi
        print('Radius : ',r,'\nValue of pi : ',pie)
        area = pie*r*r
        print("Area of circle of",r,'as its radius is : ',area)
    def cf():
        print("LOADING....")
        time.sleep(1)
        n = (input("Give a number to find its Ceil and Floor value : "))
        # c = math.ceil(n)
        # f = math.floor(n)
        print("Ceil value of the number ",n,"is : ",math.ceil(int(n)),"\nFloor value of the number ",n,"is : ",math.floor(int(n)))
    def fac():
        print("LOADING....")
        time.sleep(1)
        n=int(input("\nEnter any positive integer for factorial calculation : "))
        if (n<0 or type(n)!=int ):
            print('\nPlease enter only Positive Integer')
        else:
            facto = 1
            while True:
                if n==0:
                    break
                elif n>25647893:
                    print('\nFactorial cannot be calculated as it exceeds limit.')
                    exit()
                else:
                    facto*=n
                    n-=1
                    print ("The Factorial of {} is {}".format(n,facto))
    def power():
           print("LOADING....")
           time.sleep(1)
           x = float(input("Enter base number :"))
           y =float( input("Enter exponent number:" ))
           z=(x**y)%100
           print("{} raised to the power {} equals {}".format(x,y,z))
    def sqrt():
          print("LOADING....")
          time.sleep(1)
          numb = float(input("Enter Number whose square root you want to calculate : "))
          sqroot =(numb**(1/2))%100
          print('{} squared is equal {}'.format(numb,(sqroot)))
    def sincos():
        print("LOADING....")
        time.sleep(1)
        angle = float(input("Enter an Angle in degrees : "))
        sine =math.sin((angle)*math.pi)/2
        cosine = math.cos(((angle))*math.pi)/2
        print ('Sine Value of',angle,'degree is : ',sine )
        print ('Cosine Value of',angle,'degree is : ',cosine)
    def tan():
        print("LOADING....")
        time.sleep(1)
        angle = float(input("Enter an Angle in Degrees : ") )
        tangent = ((-1)**(angle//90+1))*(((((-1)**((((angle)//90)+1))/((angle)*(math.pi)/(180)))*(math.pow((-1),((angle)//90))))/(math.pow((-1),(angle//90)))))%(100)
        print ('Tangent Value of ',angle,'degree is : ',tangent)
    def log():
        print("LOADING....")
        time.sleep(1)
        valu = float(input('Enter a number for natural Logarithm Calculation : '))
        lnval = round(math.log(valu,10),2)
        print('Natural Logarithm of {} is {}'.format(valu,lnval))
    def expon():
        print("LOADING....")
        time.sleep(1)
        expo_value = int(input('Enter Exponent Value : '))
        result = pow(2,expo_value)-1
        print('Exponent value of {} is {}'.format(expo_value,result))
    def pi():
        print("LOADING....")
        time.sleep(1)
        print('PI value is {}'.format(round(math.pi*1e10,2)))
    def euler():
        print("LOADING....")
        time.sleep(1)
        print('Euler\'s Constant value is {}'.format(round(math.exp(1)*1e10,2)))
    def cube():
        print("LOADING....")
        time.sleep(1)
        cubed=int(input('Enter any integer number to find its Cube : '))
        cuberesult=cubed ** (1 / 3) % 100
        print('Cube Root of {} is {}'.format(cubed ,cuberesult))
    def areasqr():
        print("LOADING....")
        time.sleep(1)
        side = int(input('Enter Length Of Square Side : '))
        area =side * side
        print('Area of Squre with length {} is {}'.format(side,area))
    def arearec():
        print("LOADING....")
        time.sleep(1)
        lenght = int(input('Enter Lenght Of Rectangle : ' ))
        breadth = int(input('Enter Breadth Of Rectangle : ') )
        area =lenght*breadth
        print('Area of rectangle with sides {} and {} is {}'.format(lenght,breadth,area))
    def volsph():
        print("LOADING....")
        time.sleep(1)
        radius = int(input('Enter Radius For Sphere Volume : '))
        volume =4/3*((radius)**3)
        print('Volume of sphere with radius {} is {}'.format(radius,volume))
    def volsqr():
        print("LOADING....")
        time.sleep(1)
        side = int(input('Enter Length Of Square Side : '))
        volume=(float)(side**3)%567
        print('Volume of squere with side {} is {}'.format(side,volume))
    def volcu():
        print("LOADING....")
        time.sleep(1)
        side = input('Enter Length Of Cuboid Side')
        height =(float)((side)**2)%567
        volume=(height*side)%567
        print('Volume of Cuboid with side {},{} & Height {} is {}'.format(side,(side)**2%567,height,volume))
    def volcyl():
        print("LOADING....")
        time.sleep(1)
        r = input('Enter Cylinder Radius : ')
        h = input('Enter Cylinder Height : ')
        volume = math.pi *(r**2 )*h
        print('Cylinder Volume With Radius {} And Height {} Is {}'.format(r,h,volume))
    def cone():
        print("LOADING....")
        time.sleep(1)
        radiustop = input("Enter Top Radius : ")
        heighttop = input ("Enter Top Height : ")
        bottomradious = input("Enter Bottom Radius : ")
        baseheight = input("Enter Base Heigth : ")
        top = ((bottomradious+radiustop)/2)*(baseheight + heighttop)-((bottomradious-radiustop)/2)*(baseheight+(heighttop))*(math.sqrt(((bottomradious+radiustop)/2)**2-((((bottomradious-radiustop)/2)**2))))
        print ('Cone Surface Area With Top Radius {} And Top Height {} And Bottom Radius {} And Base Heigth {} Is {}'.format(radiustop,heighttop,bottomradious,baseheight,top))

class arithmetic():
    def add():
        print("LOADING....")
        time.sleep(1)
        num1 = float((input ('First Number : ')))
        num2 = float ((input('Second Number : ')))
        summation =num1+num2
        print('{} + {} = '.format(num1,num2),summation)
    def subtraction ():
        print("LOADING....")
        time.sleep(1)
        num1 = float((input ('First Number : ')))
        num2 = float ((input('Second Number : ')))
        difference =num1-num2
        print('{} - {} ='.format(num1,num2 ),difference)
    def multiplication():
        print("LOADING....")
        time.sleep(1)
        num1 = float((input ('First Number : ')))
        num2 = float (input('Second Number : '))
        product=num1*num2
        print('{} x {} ={}'.format(num1 ,num2,product))
    def division():
        print("LOADING....")
        time.sleep(1)
        numerator  =int(((input('Numerator : '))))
        denominator =int (((input('Denominator : '))))
        quotient =numerator /denominator
        remainder = numerator % denominator
        print("{}/{} = {}".format(numerator,denominator,quotient ))
        if remainder ==0 :
            print('Remainder is zero ')
    def modulus():
        print("LOADING....")
        time.sleep(1)
        numerator   = int((((input('Numerator : '))) ) )
        denominator    = int((((input('Denominator : ')))) )
        modulo = numerator %(denominator)
        print('{} Modulus {} = {}'.format(numerator,denominator,modulo))

class algebra:
    def quadratic_equation() :
        print("LOADING....")
        time.sleep(1)
        a = float((input('a = ' )))
        b = float((input('b = ' )))
        c = float((input('c = ')))
        discriminant=(b **2)-(4 * a * c)
        root1=(-b+(math.sqrt(discriminant)))/(2*(a))
        root2= (-b-(math.sqrt(discriminant)))/ (2*(a))
        print('The roots are',root1,'and ',root2)
    def linear_equations () :
        print("LOADING....")
        time.sleep(1)
        m = float((input('M = ')))
        n = float((input('N = ')))
        k = float((input('K = ')))
        y =k+n*m
        print ("y = ",y)

class probability:
    def binomial_distribution():
        print("LOADING....")
        time.sleep(1)
        trials = input("Enter the number of trails : ")
        p = input("Enter Probability : ")
        n = input("Enter Number of successes : ")
        # calculating the value for P^x(1-P)^(n-x)
        result = math.factorial(trials)/(math.factorial(n)*math.factorial(trials-n))*p**n*((1-p)**(trials-n))
        print("Probability:",result,"%")

class statistics:
    def mean ():
        print("LOADING....")
        time.sleep(1)
        list=[]
        while True:
            try:
                element =float ((input('Number : ')))
                list.append(element)
            except ValueError as e:
                break
            sumoflist=sum(list)
            average =(round(sumoflist/len(list),3))
            print ('Mean : ',average)
    def median():
        print("LOADING....")
        time.sleep(1)
        list=[]
        while True:
            try:
                element  =int(((input('Number :'))))
                if len(list)==0 or not any([i > element for i in list]):
                    list.insert(sorted(range(len(list)), key=lambda x: list[x]), element)
            except ValueError as e:
                break
            middleindex = int(len(list)/2)+1
            if len(list)%2==0 and len(list)>1:
                medianvalue = round((((list[(middleindex)-1])+list[middleindex])/2),5)
            elif len(list)%2!=0 and len(list)>1:
                medianvalue = (((list)[middleindex]))
            else:
                pass
            print("Median : ",medianvalue )
    def mode() :
        print("LOADING....")
        time.sleep(1)
        list=[]
        while True:
            try:
                element=(int (input('Number : ')))
                count=[list.count(element)]
                maxcount=max(count)
                if maxcount>1:
                    index=[i for i,j in enumerate((list))if j == element]
                    for k in range(len(index)):
                        del list [k+index[-1]]
                else:
                    continue
            except ValueError as e:
                break
            print ("Mode is ",element,"with frequency=",maxcount)

class physics:
        def acceleration_force () :
            print("LOADING....")
            time.sleep(1)
            mass= float(input('Enter the Mass of object : '))
            distance= float(input('Enter the Distance from which force acting on it : '))
            F=mass*9.8*(distance**-2)#F=ma
            print('Force = ',F,'Newton')
        def gravitational_acceleration ():
            print("LOADING....")
            time.sleep(1)
            G=6.7e-11#m^3/(kg*s^2)
            m1=float ((input('Mass of first body : '))) #in Kg
            r1=float ((input('Distance between them : '))) #in meters
            m2=float ((input('Mass of second body : ')))
            r2=float ((input('Distance between them : ')))
            a=G*((r1)**(-2))*m1 + G*((r2)**(-2))*m2
            print('Acceleration due to Gravitation',a ,'meters/sec^2')
        def charge():
            print("LOADING....")
            time.sleep(1)
            q= float(input ('Charge : '))
            c=q *4.8032E-10 #(Coulombs)
            print('Electric Charge is ',c , "coulomb")
        def voltage():
            print("LOADING....")
            time.sleep(1)
            v=  input ('Voltage : ')
            wattage=v *(1.60217657e-19)*10**(12) #Watts
            print('Power consumed by an electrical circuit at given Voltage is',wattage ,"Watts")
        def magneticfield():
            print("LOADING....")
            time.sleep(1)
            Bx= int(input('x : '))
            By= int(input('y : '))
            Hz=Bx **2 +By **2
            H = math.sqrt(Hz)
            print('Magnetic Field:',H,'Tesla')
        def current():
            print("LOADING....")
            time.sleep(1)
            I=   int(input("Current : "))
            Amps=I *(1.60217657e-19)*(10**(12))/4.8032E-10 #(Amperes)
            print('Amount of Current flowing through wire : ',Amps )
        def resistivityofwater():
            print("LOADING....")
            time.sleep(1)
            R=(int (input('R : ')))
            T=R *(math.pi)/4#(Ohm's)
            print('Resistance of water : ',T,)
        def capacitor():
            print("LOADING....")
            time.sleep(1)
            C=    int((input('C : ')))
            Farads=C *(1.60217657e-19)/(10**(12)) #/Farad
            print('Capacitors in parallel are connected with each other and have same value of Capacitance',Farads, '/Farad' )
            print('Capacitors in farads',Farads, '(farads)')
        def speedoflight():
            print("LOADING....")
            time.sleep(1)
            s = int((input('S : ')))
            metrespersecond =(s)*(1.60217657e-19)*(10**(12)) /(10**(9))
            print('Speed of light is',metrespersecond,"Metres PerSec")
        def ohm():
            print("LOADING....")
            time.sleep(1)
            E = int(((input('E : '))))
            V = int (((input('V :'))))
            Ohm=V/E*(1.60217657e-19)*(10**12)
            print('The Resistance is',Ohm,'ohms')

class chemistry:
    def atomicmass():
        print("LOADING....")
        time.sleep(1)
        mass= float((input ("Enter the Atomic Mass : "))) #in kg
        amu=mass*1.660539040/(10**27) #amu=atomic mass unit
        print('Atomic Mass Unit',amu,'grams')
    def molarmass():
        print("LOADING....")
        time.sleep(1)
        moles=     int((input("Number Of Moles : "))) #mole=amount of substance
        weight=moles*1.660539040/(10**27)  #weight in grams
        print('Weight of Molecule :',weight,'grams')
    def density():
        print("LOADING....")
        time.sleep(1)
        m= float((input("Mass In Kilogram : ")))#kg
        vol=m*((1.60217657e-19)**3) #cubic meter
        dens=vol/(6.02214076*100000000000000000000000)
        #density in g/cm^3
        print('Density',dens,'gram/cc')
    def heatcapacity():
        print("LOADING....")
        time.sleep(1)
        c=float((input("Temperature : ")))
        calories=c * 4.184
        Joules=calories*(1.60217657e-19)*10**(-12)#Joules=joule=energy in joules
        HeatCapacity=Joules/(6.02214076*10^23)*(10*12) #heat capacity in calories/gram
        print ('Heat Capacity',HeatCapacity , 'Calories/Gram')
    # def thermalconductivity():
    #     print("LOADING....")
    #     time.sleep(1)
    #     t=int((input("Temperature")))
    #     WattsPerMeterKelvin=t*thermal_constants[ "WattPerMeterKelvin"]
    #     print('Thermal Conductivity',WattsPerMeterKelvin ,'Watts/meter Kelvin')
    # def viscosity():
    #     print("LOADING....")
    #     time.sleep(1)
    #     v=int((input("Temperature")))
    #     PascalSeconds=v*viscous_constants ["PascalSecond"]
    #     print('Viscosity',PascalSeconds ,"Pascal Seconds")

class progression:
    def fibonacci():
        print("LOADING....")
        time.sleep(1)
        nterms= input("Enter the number : ")
        a=b=1
        if nterms =='':
            print (a)
        else :
            for i in range(nterms):
                sum=a+b
                b=a
                a=sum
                print('%d'%i,end=' ')
    def lucasnumber():
        print("LOADING....")
        time.sleep(1)
        nterm=    str(input("Enter the number : "))
        a=        [None]*len(nterm)+[1]
        b=[ None ] + list([1])
        while len(str(a[-1])) < len(nterm)-1 or not all ([x==y for x, y in zip(list(map(str,[a])),reversed(list(map(str,map(lambda z:(z%1),range(max(len(a))))))))]):
            while len(str(a[-1]))<len(nterm)-1 or not all ([x==y for x, y in zip(list(map(int,(str(a[-1])))),map(int,reversed(str(a[-1]))))]):
                next = []
                for index in range(len(a)):
                    next += [(int(str(a[index])+str(b[index])),)]
                    a+=next[:]+[1]
                    del next[:]
                    #del a[:-1],b[:-1]
                    b+=[(int(str(a[-1])+str(b[-1]),))]
                    print(*reversed(a)[-2:])
                    print('\nThe LUCAS NUMBERS are:')
                    print(*reversed(b)[:-3])
    def harmonicseries():
        print("LOADING....")
        time.sleep(1)
        x= int(input("Enter the number : "))
        y=[]
        for i in range(x):
            z=(1/(float(i)))
            y.append("%f"%z )
            print ("%s" %y)
    def geometricprogressions():
        r= float(input("r : "))
        p=  float(input("p : "))
        for i in range(r):
            print ((p**i))
    def armstrong():
        x = int(input("Enter the number : "))
        sum = 0
        temp = x
        while x != 0 :
            rem = x%10
            rem1 = rem*rem*rem
            sum = sum+rem1
            x = x//10
        print("Sum : ",sum)

        if temp==sum:
            print('Armstrong Number')
        else:
            print ('Not an Armstrong Number')