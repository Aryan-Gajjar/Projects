import codes 
from codes import mat
from codes import arithmetic
from codes import algebra
from codes import probability
from codes import physics
from codes import progression
from codes import statistics
from codes import chemistry
obj = mat
obj1 = arithmetic
obj2 = algebra
obj3 = probability
obj4 = physics
obj5 = progression
obj6 = statistics
obj7 = chemistry

def again():
    ask1 = int(input("Do you want to start the code? 1.yes/2.no : "))
    if ask1 == 1:
        ask2 = int(input("1. All Math Functions \n2. All Physics Functions \n3. All Chemistry Functions \n4. Exit \nYour Choice (input in sr.no. only) : "))
        if ask2 == 1:
            print('1.  To find Area of Circle'
                  '\n2.  To find Ceil and floor value'
                  '\n3.  To find the factorial of a number'
                  '\n4.  To find the number with power '
                  '\n5.  To find square root'
                  '\n6.  To find sin and cos value'
                  '\n7.  To tan value '
                  '\n8.  To find log '
                  '\n9.  To find exponent value '
                  '\n10. Value of pi '
                  '\n11. Euler vale'
                  '\n12. To find cube'
                  '\n13. To find area of square'
                  '\n14. To area of rectangle'
                  '\n15. To find volume of sphere'
                  '\n16. To find the volume of square'
                  '\n17. To find the volume of cube '
                  '\n18. to find the volume of cylinder'
                  '\n19. to find the volume of cone '
                  '\n20. To add two numbers'
                  '\n21. To subtract two numbers'
                  '\n22. To multiply two numbers'
                  '\n23. To divide two numbers'
                  '\n24. Modulus '
                  '\n25. to solve quadratic equation'
                  '\n26. to solve linear equation'
                  '\n27. to find the obj3'
                  '\n28. to find mean'
                  '\n29. to find median'
                  '\n30. to find mode'
                  '\n31. to find fibonacci'
                  '\n32. to find lucas number'
                  '\n33. to find harmonic series'
                  '\n34. to find geometric progressions'
                  '\n35. to find Armstrong number')
            ask3 = int(input("Enter your choice with correct sr.no. : "))
            if ask3 == 1:
                obj.circle()
                a30=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a30 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==2:
                obj.cf()
                a29=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a29 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==3:
                obj.fac()
                a28=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a28 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==4:
                obj.power()
                a27=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a27 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==5:
                obj.sqrt()
                a26=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a26 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==6:
                obj.sincos()
                a25=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a25 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==7:
                obj.tan()
                a24=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a24 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==8:
                obj.log()
                a23=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a23 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==9:
                obj.expon()
                a22=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a22 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==10:
                obj.pi()
                a21=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a21 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==11:
                obj.euler()
                a20=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a20 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==12:
                obj.cube()
                a19=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a19 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==13:
                obj.areasqr()
                a18=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a18 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==14:
                obj.arearec()
                a17=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a17 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==15:
                obj.volsph()
                a16=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a16 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==16:
                obj.volsqr()
                a15=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a15 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==17:
                obj.volcu()
                a14=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a14 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==18:
                obj.volcyl()
                a13=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a13 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==19:
                obj.cone()
                a12=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a12 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==20:
                obj1.add()
                a11=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a11 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==21:
                obj1.subtraction()
                a10=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a10 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==22:
                obj1.multiplication()
                a9=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a9 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==23:
                obj1.division()
                a8=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a8 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==24:
                obj1.modulus()
                a7=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a7 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==25:
                obj2.quadratic_equation()
                a6=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a6 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==26:
                obj2.linear_equations()
                a5=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a5 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==27:
                obj3.binomial_distribution()
                a4=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a4 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==28:
                obj6.mean()
                a3=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a3 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==29:
                obj6.median()
                a2=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a2 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==30:
                obj6.mode()
                a1=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a1 == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==31:
                obj5.fibonacci()
                p=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if p == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==32:
                obj5.lucasnumber()
                o=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if o == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==33:
                obj5.harmonicseries()
                n=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if n == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==34:
                obj5.geometricprogressions()
                m=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if m == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask3==35:
                obj5.armstrong()
                x1=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if x1 == "yes"or"YES":
                    again()
                else:
                    exit()

            else:
                print("INVALID CHOICE..")
                again()
        elif ask2==2:
            print('1. To find Acceleration Force'
                  '\n2. To find Gravitational Acceleration Force'
                  '\n3. To find the Electric Charge'
                  '\n4. To find the power consumed by an electric circuit'
                  '\n5. To find the Magnetic Field'
                  '\n6. To find the Amount of Current flowing through the wire'
                  '\n7. To find the resistance of water'
                  '\n8. OHMs Law')
            ask4 = int(input("Enter your choice with correct sr.no. : "))
            if ask4==1:
                obj4.acceleration_force()
                l=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if l == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask4==2:
                obj4.gravitational_acceleration()
                k=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if k == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask4==3:
                obj4.charge()
                j=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if j == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask4==4:
                obj4.voltage()
                i=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if i == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask4==5:
                obj4.magneticfield()
                h=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if h == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask4==6:
                obj4.current()
                g=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if g == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask4==7:
                obj4.resistivityofwater()
                f=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if f == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask4==8:
                obj4.ohm()
                e=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if e == "yes"or"YES":
                    again()
                else:
                    exit()
            else:
                print("INVALID CHOICE..")
                again()
        elif ask2==3:
            print('1. To calculate atomic mass'
                  '\n2. To calculate molar mass'
                  '\n3. To calculate density'
                  '\n4. To calculate heat capacity')
            ask5=int(input("Enter your choice with correct sr no. : "))
            if ask5==1:
                obj7.atomicmass()
                d=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if d == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask5==2:
                obj7.molarmass()
                c=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if c == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask5==3:
                obj7.density()
                b=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if b == "yes"or"YES":
                    again()
                else:
                    exit()
            elif ask5==4:
                obj7.heatcapacity()
                a=input("DO YOU WANT TO CONTINUE? (YES/NO) : ")
                if a == "yes"or"YES":
                    again()
                else:
                    exit()
            else:
                print("INVALID CHOICE..")
                again()
        elif ask2 == 4:
            exit()
        else:
            print("INVALID CHOICE..")
            exit()
    else:
        exit()
    
again()