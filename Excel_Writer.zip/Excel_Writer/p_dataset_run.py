import p_dataset_run
from p_dataset_run import excel_writer
from p_dataset_run import csv_writer
from p_dataset import read
obj_1 = excel_writer()
obj_2 = csv_writer()
obj_3 = read()

print("1. Write .xlsx file \n2. Write .csv file \n3. Convert .xlsx file to .csv file \n4. Read .xlsx file \n5. Read .csv file")
ask = int(input("ENTER YOUR CHOICE : "))
if ask == 1:
    print("**********WELCOME TO EXCEL FILE WRITER**********")
    obj_1.excel()
elif ask == 2:
    print("**********WELCOME TO CSV FILE WRITER**********")
    obj_2.csv_write()
elif ask == 3:
    print("**********WELCOME TO .xlsx TO .csv CONVERTER**********")
    obj_2.csv_convert()
elif ask == 4:
    print('********* WELCOME TO .xlsx FILE READER *********')
    obj_3.read_excel()
elif ask == 5:
    print('******** WELCOME TO .csv FILE READER ******* ')
    obj_3.read_csv()
else:
    print("\nINVALID INPUT\nPRESS F5 TO START AGAIN")