import csv
import xlsxwriter 
import pandas as pd
import time
class excel_writer():
   def excel(self):
      class store():
         def upload(self,worksheet,alpha,i1):
            ask = int(input("Enter how much data do you want to upload : "))
            print("SETTING IT UP...")
            time.sleep(1)
            index_=2
            for y in range(ask):
               letter = iter(alpha)
               for z in range(i1):
                  letter_itr = (letter.__next__())
                  num = str(letter_itr)+str(index_)
                  print("Enter the data at cell : ",num)
                  input_=input("Your data : ")
                  worksheet.write(num,input_)
                  print("Data : ",input_,"\tUploaded at ",num)
                  print("*****DATA UPLOADED*****")
               print("ROW ENTERED NOW ENTER THE OTHER ONE...")   
               letter = " "   
               index_=index_+1
            print("DATA UPLOADING....")
            time.sleep(1)
            print("*****DATA UPLOADED*****")
      obj = store()
      print("CODE INITIATING....")
      time.sleep(1)
      alpha=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
      file = input("Enter the name of the file : ")
      file_ = file+'.xlsx'
      print("CREATING FILE....")
      time.sleep(1)
      print("*****FILE CREATED*****")
      workbook = xlsxwriter.Workbook(file_)
      worksheet = workbook.add_worksheet()
      bold = workbook.add_format({'bold': True})
      i = int(input("How many columns do you want : "))
      i1=i
      item = iter(alpha)
      for x in range(i):
            head = input("Enter the column name : ") 
            index_def = (item.__next__())
            # print((index_def))
            index_no = (index_def)+str(1)  
            # print(index_no)
            print("YOUR DATA IS ENTERED AT CELL ",index_no)
            worksheet.write(index_no,head,bold)
      time.sleep(1)
      print("SUCCESSFULLY CREATED COLUMNS HEADINGS....")
      obj.upload(worksheet,alpha,i1)
      workbook.close()
      return file_
   
   
class csv_writer(excel_writer):
   def csv_convert(self):
      x = input("Enter the name of the excel file that you want to convert : ")
      df = pd.read_excel(x)
      print("CONVERTING TO .csv....")
      time.sleep(0.5)
      y = input("Enter csv file name : ")
      
      z=y+'.csv'
      df.to_csv(z, index=False)

   def csv_write(self):
      file_csv = input("Enter the file name : ")
      file_csv_ = file_csv+'.csv'
      with open(file_csv_, 'w', newline='') as csvfile:
         csvwriter = csv.writer(csvfile)
         head = input("enter the headings : ").split()
         csvwriter.writerow(head)
         while True:
            input_ = input("Enter an input(in the same format as the headings are given): ").split()
            if input_ == ["quit"]:
                  break
            csvwriter.writerow(input_)

class read():
   def read_excel(self):
      file_name_xlsx = input("Enter the file name : ")
      file_name_str_xlsx = str(file_name_xlsx)+'.xlsx'
      data_xlsx = pd.read_excel(file_name_str_xlsx)
      print("Reading Data...")
      print(data_xlsx)
   def read_csv(self):
      file_name_csv = input("Enter the file name : ")
      file_name_str_csv = str(file_name_csv)+'.csv'
      data_csv = pd.read_csv(file_name_str_csv)
      print("Reading Data...")
      print(data_csv)

class info_():
   def info_excel():
      file_name_xlsx = input("Enter the file name : ")
      file_name_str_xlsx = str(file_name_xlsx)+'.xlsx'
      data_xlsx = pd.read_excel(file_name_str_xlsx)
      print("Reading Data And Fetching Information...")
      print(data_xlsx.info())
   def info_csv():
      file_name_csv = input("Enter the file name : ")
      file_name_str_csv = str(file_name_csv)+'.csv'
      data_csv = pd.read_csv(file_name_str_csv)
      print("Reading Data And Fetching Information...")
      print(data_csv.info()) 