﻿using BPMeasurementApplication.Models;
using BPMeasurementApplication.Services;
using BPMeasurementApplication.Entities;
using Microsoft.AspNetCore.Mvc;

namespace BPMeasurementApplication.Controllers
{
	public class BPMeasurementController : Controller
	{
		private readonly IBPMeasurementService _bpmMeasurementService;
		public BPMeasurementController(IBPMeasurementService bpmMeasurementService)
		{
		  _bpmMeasurementService = bpmMeasurementService;
		}

        [HttpGet("/information")]
        public IActionResult Information()
        {
            return View("Information");
        }

        [HttpGet("/all")]
		public IActionResult AllRecords()
		{
			var viewModel = new AllBPRecordsViewModel()
			{
				AllBloodPressureRecords = _bpmMeasurementService.GetAllBloodPressureRecords(),
			};
			return View("All",viewModel);
		}


		[HttpGet("/add")]
		public IActionResult AddRecord()
		{
			var viewModel = new AddBPRecordViewModel()
			{
				NewBloodPressureRecord = new BloodPressureRecord()
			};

			return View("Add", viewModel);
		}

		[HttpPost("/add")]
		public IActionResult AddRecord(AddBPRecordViewModel viewModel)
		{
			if (!ModelState.IsValid)
			{
				return View("Add", viewModel);
			}
			else
			{
				_bpmMeasurementService.AddRecord(viewModel.NewBloodPressureRecord);
				TempData["message"] = $"{viewModel.NewBloodPressureRecord.Systolic}/{viewModel.NewBloodPressureRecord.Diastolic} added successfully!";
				TempData["className"] = "success";

				return RedirectToAction("AllRecords");
			}

		}
			[HttpGet("/edit/{RecordId}")]
			public IActionResult EditRecord(int RecordId)
			{
				var viewModel = new EditBPRecordViewModel()
				{
					CurrentBloodPressureRecord = _bpmMeasurementService.GetRecordById(RecordId),
				};

				return View("Edit", viewModel);
			}


			[HttpPost("/edit/{RecordId}")]
			public IActionResult EditRecord(EditBPRecordViewModel viewModel)
			{
				if (!ModelState.IsValid)
				{
					return View("Edit", viewModel);
				}
				else
				{
					_bpmMeasurementService.UpdateRecord(viewModel.CurrentBloodPressureRecord);
					TempData["message"] = $"{viewModel.CurrentBloodPressureRecord.Systolic}/{viewModel.CurrentBloodPressureRecord.Diastolic} updated successfully!";
					TempData["className"] = "info";

					return RedirectToAction("AllRecords");
				}

			}

			[HttpGet("/delete/{RecordId}")]
			public IActionResult DeleteRecord(int RecordId)
			{
				var viewModel = new DeleteBPRecordViewModel()
				{
					CurrentBloodPressureRecord = _bpmMeasurementService.GetRecordById(RecordId)
				};

				return View("Delete", viewModel);
			}


			[HttpPost("/delete/{RecordId}")]
			public IActionResult DeleteRecord(DeleteBPRecordViewModel viewModel)
			{
				_bpmMeasurementService.DeleteRecord(viewModel.CurrentBloodPressureRecord);
				TempData["message"] = $"{viewModel.CurrentBloodPressureRecord.Systolic}/{viewModel.CurrentBloodPressureRecord.Diastolic} deleted successfully!";
				TempData["className"] = "danger";

				return RedirectToAction("AllRecords");
			}
		}
	}
