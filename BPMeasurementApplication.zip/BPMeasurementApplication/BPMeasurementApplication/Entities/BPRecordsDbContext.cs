﻿using Microsoft.EntityFrameworkCore;

namespace BPMeasurementApplication.Entities
{
	public class BPRecordsDbContext : DbContext
	{
		public BPRecordsDbContext(DbContextOptions<BPRecordsDbContext> options) : base(options)
		{

		}
		public DbSet<BloodPressureRecord> BloodPressureRecords { get; set; }
       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
		{

        
            modelBuilder.Entity<BloodPressureRecord>().HasKey(b => b.RecordId);
            modelBuilder.Entity<BloodPressureRecord>().Ignore(b => b.Category);
           


            modelBuilder.Entity<BloodPressureRecord>().HasData(
				new BloodPressureRecord { RecordId = 1, Systolic = 120, Diastolic = 80,  Date = new DateTime(2024, 9, 1)},
				new BloodPressureRecord { RecordId = 2, Systolic = 130, Diastolic = 90,  Date = new DateTime(2024, 9, 2)},
				new BloodPressureRecord { RecordId = 3, Systolic = 140, Diastolic = 100, Date = new DateTime(2024, 9, 3	)}
				);
		}
	}
}
	