﻿using System.ComponentModel.DataAnnotations;

namespace BPMeasurementApplication.Entities
{
    
    public class BloodPressureRecord
    {
        [Key]
        public int RecordId { get; set; }

        [Required(ErrorMessage = "Please enter your score.")]
        [Range(20, 400, ErrorMessage = "Systolic must be between 20 and 400.")]
        public int? Systolic { get; set; }

        [Required(ErrorMessage = "Please enter your score.")]
        [Range(10, 300, ErrorMessage = "Diastolic must be between 10 and 300.")]
        public int? Diastolic { get; set; }




        [Required(ErrorMessage = "Please enter the date.")]
        //[Range(typeof(DateTime), "9/1/2024", "9/30/2024", ErrorMessage = "Date should be in September 2024")]
        public DateTime? Date { get; set; }

        

        public string Category
        {
            get
            {
               
                if (Systolic.HasValue && Diastolic.HasValue)
                {
                    if (Systolic < 120 && Diastolic < 80)
                        return "Normal";
                    else if (Systolic >= 120 && Systolic < 130 && Diastolic < 80)
                        return "Elevated";
                    else if (Systolic >= 130 && Systolic < 140 && Diastolic >= 80 && Diastolic < 90)
                        return "Hypertension Stage 1";
                    else if ((Systolic >= 140 && Systolic < 180) || (Diastolic >= 90 && Diastolic < 120))
                        return "Hypertension Stage 2";
                    else if (Systolic > 180 || Diastolic > 120)
                        return "Hypertensive Crisis";
                    else
                        return "Uncategorized";
                }

                return "Uncategorized";
            }
        }
    }
}