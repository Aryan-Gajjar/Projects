﻿using BPMeasurementApplication.Entities;

namespace BPMeasurementApplication.Services
{
	public class BPMeasurementService : IBPMeasurementService
	{
		private readonly BPRecordsDbContext _context;

		public BPMeasurementService(BPRecordsDbContext context)
		{
			_context = context;
		}

		public List<BloodPressureRecord> GetAllBloodPressureRecords()
		{
			return _context.BloodPressureRecords.ToList();	
		}

		public BloodPressureRecord GetRecordById(int id)
		{
			return _context.BloodPressureRecords.Find(id);
		}

		public int AddRecord(BloodPressureRecord record)
		{
			_context.BloodPressureRecords.Add(record);
			_context.SaveChanges();
			return record.RecordId;
		}

		public int UpdateRecord(BloodPressureRecord record)
		{
			_context.BloodPressureRecords.Update(record);
			_context.SaveChanges();
			return record.RecordId;
		}

		public int DeleteRecord(BloodPressureRecord record)
		{
			_context.BloodPressureRecords.Remove(record);
			_context.SaveChanges();
			return record.RecordId;
		}
	}
}
