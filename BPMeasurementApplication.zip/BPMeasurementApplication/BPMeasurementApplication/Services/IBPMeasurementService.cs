﻿using BPMeasurementApplication.Entities;

namespace BPMeasurementApplication.Services
{
	public interface IBPMeasurementService
	{
		public List<BloodPressureRecord> GetAllBloodPressureRecords();

		public BloodPressureRecord GetRecordById(int id);
		public int AddRecord(BloodPressureRecord record);

		public int UpdateRecord(BloodPressureRecord record);
		public int DeleteRecord(BloodPressureRecord record);
	}
}
