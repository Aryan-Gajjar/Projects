﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BPMeasurementApplication.Migrations
{
    /// <inheritdoc />
    public partial class UpdateBloodPressureRecord : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Category",
                table: "BloodPressureRecords");

            migrationBuilder.UpdateData(
                table: "BloodPressureRecords",
                keyColumn: "RecordId",
                keyValue: 2,
                column: "Date",
                value: new DateTime(2024, 9, 2, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "BloodPressureRecords",
                keyColumn: "RecordId",
                keyValue: 3,
                column: "Date",
                value: new DateTime(2024, 9, 3, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "BloodPressureRecords",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "BloodPressureRecords",
                keyColumn: "RecordId",
                keyValue: 1,
                column: "Category",
                value: "Normal");

            migrationBuilder.UpdateData(
                table: "BloodPressureRecords",
                keyColumn: "RecordId",
                keyValue: 2,
                columns: new[] { "Category", "Date" },
                values: new object[] { "Pre-Hypertension", new DateTime(2024, 9, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                table: "BloodPressureRecords",
                keyColumn: "RecordId",
                keyValue: 3,
                columns: new[] { "Category", "Date" },
                values: new object[] { "Hypertension", new DateTime(2024, 9, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });
        }
    }
}
