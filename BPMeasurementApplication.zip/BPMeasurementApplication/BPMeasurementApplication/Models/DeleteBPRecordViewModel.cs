﻿using BPMeasurementApplication.Entities;

namespace BPMeasurementApplication.Models
{
	public class DeleteBPRecordViewModel
	{
		public BloodPressureRecord CurrentBloodPressureRecord { get; set; }
	}
}
