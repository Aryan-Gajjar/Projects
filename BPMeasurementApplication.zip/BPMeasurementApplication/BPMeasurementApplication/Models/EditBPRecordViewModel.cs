﻿using BPMeasurementApplication.Entities;

namespace BPMeasurementApplication.Models
{
	public class EditBPRecordViewModel
	{
		public BloodPressureRecord CurrentBloodPressureRecord { get; set; }
	}
}
