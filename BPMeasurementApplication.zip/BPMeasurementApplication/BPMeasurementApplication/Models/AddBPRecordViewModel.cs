﻿using BPMeasurementApplication.Entities;

namespace BPMeasurementApplication.Models
{
	public class AddBPRecordViewModel
	{ 
		public BloodPressureRecord NewBloodPressureRecord { get; set; }
	}
}
