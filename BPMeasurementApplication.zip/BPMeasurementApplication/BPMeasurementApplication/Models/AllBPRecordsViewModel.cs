﻿using BPMeasurementApplication.Entities;

namespace BPMeasurementApplication.Models
{
	public class AllBPRecordsViewModel
	{
		public List<BloodPressureRecord> AllBloodPressureRecords { get; set; } 
	}
}
