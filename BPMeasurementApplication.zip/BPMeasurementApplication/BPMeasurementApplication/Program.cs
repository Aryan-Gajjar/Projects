using BPMeasurementApplication.Entities;
using BPMeasurementApplication.Services;
using Microsoft.EntityFrameworkCore;

namespace BPMeasurementApplication
{
	public class Program
	{
		public static void Main(string[] args)
		{
			var builder = WebApplication.CreateBuilder(args);

			// Add services to the container.
			builder.Services.AddControllersWithViews();

			var connectingString = builder.Configuration.GetConnectionString("BPRecordsDb");
			builder.Services.AddDbContext<BPRecordsDbContext>(options => options.UseSqlServer(connectingString));

			builder.Services.AddScoped<IBPMeasurementService, BPMeasurementService>();


			var app = builder.Build();

			// Configure the HTTP request pipeline.
			if (!app.Environment.IsDevelopment())
			{
				app.UseExceptionHandler("/Home/Error");
			}
			app.UseStaticFiles();

			app.UseRouting();

			app.UseAuthorization();

			app.MapControllerRoute(
				name: "default",
				pattern: "{controller=Home}/{action=Index}/{id?}");

			app.Run();
		}
	}
}
