#Project jarvis

import speech_recognition as sr #pip install speech_recognition  //

import datetime #pip install datetime

import wikipedia #pip install wikipedia

import pyttsx3 #pip intall pyttsx3

import webbrowser #pip install webbrowser  //

import random #pip install random

import os #pip install os

import pyjokes #pip install pyjokes

import wolframalpha #pip install wolframealpha

try:

    app = wolframalpha.Client( "LW4KRW-QEQVW8PPLL")

except Exception:

    print("some features are not working")

#Text To Speech

engine = pyttsx3.init('sapi5')

voices = engine.getProperty('voices')

#print(voices)

engine.setProperty('voice',voices[1].id)

def speak(audio):  #here audio is var which contain text

    engine.say(audio)

    engine.runAndWait()

def jokes():

    speak(pyjokes.get_jokes())    

def wish():

    hour = int(datetime.datetime.now().hour)

    if hour >= 0 and hour<12:

        speak("good morning sir")

    elif hour>=12 and hour<18:

        speak("good afternoon sir") 

    else:

        speak("good evening sir")  

#now convert audio to text

# 

def takecom():

    r = sr.Recognizer()

    with sr.Microphone() as source:

        print("Listning....")

        audio = r.listen(source)

    try:

        print("Recognising.") 

        text = r.recognize_google(audio,language='en-in')

        print(text)

    except Exception:                #For Error handling

        speak("Sir can you please repeat again")

        print("Network connection error") 

        return "none"

    return text

#for main function                               

if __name__ == "__main__":

    wish()

    while True:

        query = takecom().lower()

        if "wikipedia" in query:

            speak("searching details....Wait")

            query.replace("wikipedia","")

            results = wikipedia.summary(query,sentences=2)

            print(results)

            speak(results)

        elif "my location" in query:

            import phonenumbers  #pip install phonenumbers

            aryan = '+13828850752'

            from phonenumbers import geocoder

            ch_nmber = phonenumbers.parse(aryan, "CH")

            print (geocoder.description_for_number(ch_nmber, "en"))

            speak(geocoder.description_for_number(ch_nmber, "en"))

            webbrowser.open("D:/mylocation.html")

            from phonenumbers import carrier

            service_nmber = phonenumbers.parse(aryan, "RO")

            print(carrier.name_for_number(service_nmber, "en"))

            speak(carrier.name_for_number(service_nmber, "en"))

            from opencage.geocoder import OpenCageGeocode

            yourlocation = geocoder.description_for_number(ch_nmber, "en")

            geocoder = OpenCageGeocode('3a4094aa4d8f4d0b9042d480e7a549da')

            query = str(yourlocation)

            results = geocoder.geocode(query)

            print(results)

            lat = results[0]['geometry']['lat']

            lng = results[0]['geometry']['lng']

            print(lat, lng)

            import folium #pip install folium

            myMap = folium. Map(location = [lat, lng], zoomstart_= 9)

            folium.Marker([lat, lng],popup= yourlocation).add_to((myMap))

            myMap.save('mylocation.html')

            webbrowser.open("#file location")

        elif "kush " in query:

            import phonenumbers  #pip install phonenumbers

            from test import number

            from phonenumbers import geocoder

            ch_nmber = phonenumbers.parse(number, "CH")

            print (geocoder.description_for_number(ch_nmber, "en"))

            speak(geocoder.description_for_number(ch_nmber, "en"))

            webbrowser.open("#file location")

            from phonenumbers import carrier

            service_nmber = phonenumbers.parse(number, "RO")

            print(carrier.name_for_number(service_nmber, "en"))

            speak(carrier.name_for_number(service_nmber, "en"))

            from opencage.geocoder import OpenCageGeocode

            yourlocation = geocoder.description_for_number(ch_nmber, "en")

            geocoder = OpenCageGeocode('3a4094aa4d8f4d0b9042d480e7a549da')

            query = str(yourlocation)

            results = geocoder.geocode(query)

            print(results)

            lat = results[0]['geometry']['lat']

            lng = results[0]['geometry']['lng']

            print(lat, lng)

            import folium #pip install folium

            myMap = folium. Map(location = [lat, lng], zoomstart_= 9)

            folium.Marker([lat, lng],popup= yourlocation).add_to((myMap))

            myMap.save('mylocation.html')

             

        elif 'jarvis open youtube' in query or "open youtube" in query:

            webbrowser.open("www.youtube.com")

            speak("opening youtube")

        elif 'jarvis show me todays news' in query or "what is today's news" in query:

            webbrowser.open("https://www.ndtv.com/latest")

            speak("ok! let me search for some news") 

        elif 'jarvis open newspaper' in query or "open divya bhaskar" in query:

            webbrowser.open("https://epaper.divyabhaskar.co.in/ahmedabad/12/29042021/0/-1/")

            speak("opening divyabhaskar")         

        elif 'jarvis open github' in query or "open github" in query:

            webbrowser.open("https://www.github.com")

            speak("opening github")  

        elif 'jarvis open facebook' in query or "open facebook" in query:

            webbrowser.open("https://www.facebook.com")

            speak("opening facebook")      

        elif 'jarvis open instagram' in query or "open instagram" in query:

            webbrowser.open("https://www.instagram.com")

            speak("opening instagram")    

        elif 'jarvis open google' in query or "open google" in query:

            webbrowser.open("https://www.google.com")

            speak("opening google")

        elif 'jarvis open yahoo' in query or "open yahoo" in query:

            webbrowser.open("https://www.yahoo.com")

            speak("opening yahoo")

        elif 'jarvis open gmail' in query or "open gmail" in query:

            webbrowser.open("https://mail.google.com")

            speak("opening google mail")     

        elif 'jarvis open tinkercad' in query or "open tinkercad" in query:

            webbrowser.open("https://www.tinkercad.com/dashboard") 

            speak("opening tinkercad")  

        elif 'jarvis open amazon' in query or 'suggest a website where i could shop online' in query:

            webbrowser.open("https://www.amazon.com")

            speak("opening amazon")

        elif 'jarvis open flipkart' in query or "open flipkart" in query:

            webbrowser.open("https://www.flipkart.com")

            speak("opening flipkart")   

        elif 'jarvis open ebay' in query or "suggest a best reselling website" in query:

            webbrowser.open("https://www.ebay.com")

            speak("opening ebay")

        elif 'jarvis play music from my pc' in query or "music" in query:

            speak("ok i am playing music")

            n = random.randint(0, 10)

            print(n)

            music_dir = "C:/Users/aryan/Music"


            musics = os.listdir(music_dir)

            os.startfile(os.path.join(music_dir,musics[n]))

        elif 'jarvis i am bored' in query or "jarvis i am stressed do you have anything which can help me" in query:

            speak("ok! let me play some music")

            music_dir = "C:/Users/aryan/Music"

            musics = os.listdir(music_dir)

            os.startfile(os.path.join(music_dir,musics[0]))

        elif 'jarvis play video from my pc' in query or "play video" in query:

            speak("ok i am playing videos")

            video_dir = '#video file location'

            videos = os.listdir(music_dir)

            os.startfile(os.path.join(video_dir,videos[0]))  

        elif 'goodbye jarvis' in query:

            speak("good bye sir")

            exit()

        elif "shutdown" in query:

            speak("shutting down")

            os.system('shutdown -s') 

        elif "whats up" in query or 'how are you' in query:

            stMsgs = ['Just doing my thing!', 'I am fine!', 'Nice!', 'I am nice and full of energy','i am okey ! How are you']

            ans_q = random.choice(stMsgs)

            speak(ans_q)  

            ans_take_from_user_how_are_you = takecom()

            if 'fine' in ans_take_from_user_how_are_you or 'happy' in ans_take_from_user_how_are_you or 'okey' in ans_take_from_user_how_are_you:

                speak('okey..')  

            elif 'not' in ans_take_from_user_how_are_you or 'sad' in ans_take_from_user_how_are_you or 'upset' in ans_take_from_user_how_are_you:

                speak('oh sorry..') 

        elif 'make you' in query or 'who created you' in query or 'by whom you were developed' in query:

            ans_m = " For your information your name Created me ! I give Lot of Thanks to Him "

            print(ans_m)

            speak(ans_m)

        elif 'check the system' in query:

            A = "System is doing great and i have charged it to 100% and your system is updated"

            print(A)

            speak(A)

        elif 'thanks for updating the system' in query:

            B = 'if you dont do anything then i have to do it for sure'

            print(B)

            speak(B)

        elif 'i forgot' in query:

            C = 'No problem sir..'

            print(C)

            speak(C)

        elif'do you have a girlfriend' in query:

            D = 'No sir i used to have but thanos just blast our base where i was leaveing with friday'

            print(D)

            speak(D)

        elif "who are you" in query or "about you" in query or "your details" in query:

            about = "I am jarvis an A I based computer program but i can help you lot like a your close friend ! i promise you ! Simple try me to give simple command ! like playing music or video from your directory i also play video and song from web or online ! i can also entain you i so think you Understand me ! ok Lets Start "

            print(about)

            speak(about)

        elif  "hello" in query:

            hel = "Hello Sir ! How May i Help you.."

            print(hel)

            speak(hel)

        elif 'joke'in query:

            jokes() 

            speak(jokes())                 

        elif  "thank you" in query:

            hel = "your welcome sir..."

            print(hel)

            speak(hel)    

        elif "what is your name" in query or "what is your sweet name" in query:

            na_me = "My self jarvis! thanks for asking my name..."  

            print(na_me)

            speak(na_me)

        elif "How are you feeling today" in query:

            print("feeling Very sweet after meeting with you")

            speak("feeling Very sweet after meeting with you") 

        elif "good job jarvis" in query:

            print("thank you sir for the appreciation")

            speak("thank you sir for the appreciation") 

        elif query == 'none':

            continue 

        elif 'exit' in query or 'abort' in query or 'stop' in query or 'good bye jarvis' in query or 'can you please stop jarvis' in query :

            ex_exit = 'I feeling very sweet after meeting with you but you are going! i am very sad'

            speak(ex_exit)

            exit() 

        elif 'lunch'in query:

            ex_exit = 'okay sir go and enjoy your lunch till then i will complete my remaning trainings'

            speak(ex_exit)

            exit()

        elif 'breakfast'in query:

            ex_exit = 'okay sir go and enjoy your breakfast till then i will complete my remaning trainings'

            speak(ex_exit)

            exit()

        elif 'dinner'in query:

            ex_exit = 'okay sir go and enjoy your dinner till then i will complete my remaning trainings'

            speak(ex_exit)

            exit()

        elif 'temperature'in query:

            try:

                res = app.query(query)

                print(next(res.results).text)

                speak(next(res.results).text) 

            except:  # noqa: E722

                print("Database Not Found")

        else:

            try:

                res = app.query(query)

                print(next(res.results).text)

                speak(next(res.results).text) 

            except:  # noqa: E722

                print("Database Not Found")                  

        