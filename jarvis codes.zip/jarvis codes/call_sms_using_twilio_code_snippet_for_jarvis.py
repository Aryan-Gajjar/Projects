        elif "send a message" in query:

            speak("sir whatshould i say")

            msz = takecom()

            from twilio.rest import Client    

            account_sid = '#get your own account sid from twilio'

            auth_token = '#get your own auth token from twilio '

            client = Client(account_sid, auth_token)

            message = client.messages \

            .create(

                  body = msz,

                  from_='#get your free mobile no from twilio’,

                  to='#persons mobile no.to whom you want to msg’

                )

            print(message.sid) 

        elif 'call mom'in query or "call mummy" in query: 

         from twilio.rest import Client

         account_sid = '#get your own account sid from twilio''

         auth_token = '#get your own auth token from twilio''

         client = Client(account_sid, auth_token)

         message = client.calls \

             .create(

                  twiml='<Response><Say> This is the second testing message from Jrvis side..</Say></Response>',

                  from_='get your free mobile no from twilio,

                  to='persons mobile no.to whom you want to call’

                )

         print(message.sid) 