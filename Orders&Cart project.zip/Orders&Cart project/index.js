const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');

const app = express();
const port = 8080;

// Database connection
mongoose.connect('mongodb://localhost:27017/FinalTerm_JuiceShop_AG', { useNewUrlParser: true, useUnifiedTopology: true });

// Mongoose schemas and models
const adminSchema = new mongoose.Schema({
    username: String,
    password: String
});

const orderSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required'],
        match: [/^[a-zA-Z\s]+$/, 'Please enter a valid name']
    },
    phone: {
        type: String,
        required: [true, 'Phone number is required'],
        match: [/^\d{10}$|^\d{3}-\d{3}-\d{4}$/, 'Please enter a valid phone number in the format 1234567890 or 123-123-1234']
    },
    mangoJuices: {
        type: Number,
        default: 0
    },
    berryJuices: {
        type: Number,
        default: 0
    },
    appleJuices: {
        type: Number,
        default: 0
    },
    subTotal: Number,
    tax: Number,
    totalCost: Number
});

const Admin = mongoose.model('admin', adminSchema);
const Order = mongoose.model('allOrders', orderSchema);


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

// Session 
app.use(session({
    secret: 'yourSecretKey', 
    saveUninitialized: false,
    cookie: { secure: false } 
}));

// Middleware to check if user is authenticated and redirect to login if not
function isAuthenticated(req, res, next) {
    if (!req.session.isAuthenticated) {
        return res.redirect('/login');
    }
    return next();
}

// Routes
app.get('/', (req, res) => {
    res.redirect('/login');
});

app.get('/login', (req, res) => {
    req.session.destroy(); 
    res.render('loginpage');
});

app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const admin = await Admin.findOne({ username, password });

        if (admin) {
            req.session.isAuthenticated = true; 
            res.redirect('/order');
        } else {
            res.render('loginpage', { error: 'Invalid username or password' });
        }
    } catch (err) {
        console.error(err);
        res.render('loginpage', { error: 'An error occurred. Please try again.' });
    }
});

app.get('/order', isAuthenticated, (req, res) => {
    res.render('orderpage');
});

app.post('/order', isAuthenticated, async (req, res) => {
    try {
        const { name, phone, mangoJuices, berryJuices, appleJuices } = req.body;

        // Normalize phone number format (remove dashes if needed)
        const normalizedPhone = phone.replace(/-/g, '');

        const mangoPrice = 2.99;
        const berryPrice = 1.99;
        const applePrice = 2.49;
        const subTotal = (mangoJuices * mangoPrice) + (berryJuices * berryPrice) + (appleJuices * applePrice);
        const tax = subTotal * 0.13;
        const totalCost = subTotal + tax;

        const newOrder = new Order({
            name,
            phone: normalizedPhone,
            mangoJuices,
            berryJuices,
            appleJuices,
            subTotal,
            tax,
            totalCost
        });

        await newOrder.save();

        res.render('thankyou', { name, phone, mangoJuices, berryJuices, appleJuices, subTotal, tax, totalCost });
    } catch (err) {
        console.error(err);
        res.render('orderpage', { error: 'Failed to process your order. Please try again.' });
    }
});

app.get('/allorders', isAuthenticated, async (req, res) => {
    try {
        const orders = await Order.find();  // Fetching all orders from the database
        res.render('allorders', { orders });
    } catch (err) {
        console.error(err);
        res.status(500).send("There was an error retrieving the orders.");
    }
});

// Server
app.listen(port, () => {
    console.log('Server running on http://localhost:8080');
});
