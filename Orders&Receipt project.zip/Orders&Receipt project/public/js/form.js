document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    const product1Input = form.querySelector('input[name="product1"]');
    const product2Input = form.querySelector('input[name="product2"]');
    const product3Input = form.querySelector('input[name="product3"]');
    const provinceSelect = form.querySelector('select[name="province"]');
    const totalDisplay = document.getElementById('total-display');
    const subTotalDisplay = document.getElementById('subtotal-display');
    const taxDisplay = document.getElementById('tax-display');

    const productPrices = {
        product1: 10,
        product2: 20,
        product3: 30
    };

    const taxRates = {
        "Alberta": 0.05,
        "British Columbia": 0.12,
        "Manitoba": 0.12,
        "New Brunswick": 0.15,
        "Newfoundland and Labrador": 0.15,
        "Northwest Territories": 0.05,
        "Nova Scotia": 0.15,
        "Nunavut": 0.05,
        "Ontario": 0.13,
        "Prince Edward Island": 0.15,
        "Quebec": 0.14975,
        "Saskatchewan": 0.11,
        "Yukon": 0.05
    };

    const calculateTotal = () => {
        const product1 = parseInt(product1Input.value) || 0;
        const product2 = parseInt(product2Input.value) || 0;
        const product3 = parseInt(product3Input.value) || 0;
        const province = provinceSelect.value;

        const subTotal = (product1 * productPrices.product1) +
                         (product2 * productPrices.product2) +
                         (product3 * productPrices.product3);

        const taxRate = taxRates[province] || 0.13;
        const tax = subTotal * taxRate;
        const total = subTotal + tax;

        subTotalDisplay.textContent = `Subtotal: $${subTotal.toFixed(2)}`;
        taxDisplay.textContent = `Tax: $${tax.toFixed(2)}`;
        totalDisplay.textContent = `Total: $${total.toFixed(2)}`;
    };

    form.addEventListener('input', calculateTotal);

    form.addEventListener('submit', (event) => {
        let errors = [];

        const name = form.querySelector('input[name="firstName"]').value.trim();
        const lastName = form.querySelector('input[name="lastName"]').value.trim();
        const email = form.querySelector('input[name="email"]').value.trim();
        const phone = form.querySelector('input[name="phone"]').value.trim();
        const address1 = form.querySelector('input[name="address1"]').value.trim();
        const city = form.querySelector('input[name="city"]').value.trim();
        const province = form.querySelector('select[name="province"]').value.trim();

        if (!name || !lastName) errors.push("Full name is required.");
        if (!email || !/\S+@\S+\.\S+/.test(email)) errors.push("Valid email is required.");
        if (!phone || !/^\d{3}-\d{3}-\d{4}$/.test(phone)) errors.push("Valid phone number is required (e.g., 555-555-5555).");
        if (!address1) errors.push("Address is required.");
        if (!city) errors.push("City is required.");
        if (!province) errors.push("Province is required.");

        const subTotal = (parseInt(product1Input.value) || 0) * productPrices.product1 +
                         (parseInt(product2Input.value) || 0) * productPrices.product2 +
                         (parseInt(product3Input.value) || 0) * productPrices.product3;

        if (subTotal < 10) errors.push("Minimum purchase should be $10.");

        if (errors.length > 0) {
            event.preventDefault();
            alert(errors.join('\n'));
        }
    });

    calculateTotal(); // Initial calculation
});
