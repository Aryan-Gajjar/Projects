const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');

const app = express();
const PORT = 8080;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const taxRates = {
    "Alberta": 0.05,
    "British Columbia": 0.12,
    "Manitoba": 0.12,
    "New Brunswick": 0.15,
    "Newfoundland and Labrador": 0.15,
    "Northwest Territories": 0.05,
    "Nova Scotia": 0.15,
    "Nunavut": 0.05,
    "Ontario": 0.13,
    "Prince Edward Island": 0.15,
    "Quebec": 0.14975,
    "Saskatchewan": 0.11,
    "Yukon": 0.05
};

// MongoDB connection setup
mongoose.connect('mongodb://localhost:27017/myshop_assignment4', { useNewUrlParser: true, useUnifiedTopology: true });

const orderSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    email: String,
    phone: String,
    address1: String,
    city: String,
    postalCode: String,
    province: String,
    products: Object,
    subTotal: Number,
    salesTax: Number,
    total: Number,
    deliveryTime: String
});

const Order = mongoose.model('orders', orderSchema);

// Route to serve the form
app.get('/', (req, res) => {
    res.render('form', { errors: [], formData: {} });
});

// Route to handle form submission
app.post('/submit', async (req, res) => {
    const { firstName, lastName, email, phone, address1, city, postalCode, province, product1, product2, product3, deliveryTime } = req.body;

    // Server-side validation
    let errors = [];
    if (!firstName) errors.push("First name is required.");
    if (!lastName) errors.push("Last name is required.");
    if (!email || !/\S+@\S+\.\S+/.test(email)) errors.push("Valid email is required.");
    if (!phone || !/^\d{3}-\d{3}-\d{4}$/.test(phone)) errors.push("Valid phone number is required (e.g., 555-555-5555).");
    if (!address1) errors.push("Address is required.");
    if (!city) errors.push("City is required.");
    if (!province) errors.push("Province is required.");
    if (!postalCode) errors.push("Postal code is required.");

    const productPrices = { product1: 10, product2: 20, product3: 30 };
    const products = {
        product1: { name: "Product 1", quantity: parseInt(product1) || 0, price: productPrices.product1 },
        product2: { name: "Product 2", quantity: parseInt(product2) || 0, price: productPrices.product2 },
        product3: { name: "Product 3", quantity: parseInt(product3) || 0, price: productPrices.product3 },
    };

    const subTotal = Object.values(products).reduce((sum, product) => sum + product.quantity * product.price, 0);

    if (subTotal < 10) errors.push("Minimum purchase should be $10.");

    if (errors.length > 0) {
        res.render('form', { errors, formData: req.body });
    } else {
        const taxRate = taxRates[province] || 0.13; // Default to 13% if province not found
        const salesTax = subTotal * taxRate;
        const total = subTotal + salesTax;
        const name = firstName+" "+lastName;
        const address = address1; 
        

        const order = new Order({
            firstName, lastName, email, phone, address, city, postalCode, province, products, subTotal, salesTax, total, deliveryTime
        });

        await order.save();

        res.render('receipt', { name, email, phone, address, city, postalCode, province, products, subTotal, salesTax, total, deliveryTime });
    }
});

// Route to display all orders
app.get('/orders', async (req, res) => {
    const orders = await Order.find({});
    res.render('orders', { orders });
});

app.listen(PORT, () => {
    console.log('Server is running on port http://localhost:8080');
});
